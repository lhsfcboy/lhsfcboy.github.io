public class Lion extends Mammal{	
	public void makeNoise() {
		System.out.println("grrrrrrr! roar");
	}
}
