public class Dog extends Mammal{	
	public void makeNoise() {
		System.out.println("woof woof");
	}
}
