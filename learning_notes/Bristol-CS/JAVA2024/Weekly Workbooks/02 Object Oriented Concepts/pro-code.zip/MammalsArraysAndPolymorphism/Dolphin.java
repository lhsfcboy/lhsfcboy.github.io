public class Dolphin extends Mammal{	
	public void makeNoise() {
		System.out.println("squeek click");
	}
}
