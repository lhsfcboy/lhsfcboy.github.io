Code by Derek Banas (not Sion!):

http://www.newthinktank.com/2013/02/mvc-java-tutorial/
https://www.youtube.com/watch?v=dTVVa2gfht8
